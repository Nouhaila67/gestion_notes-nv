package com.example.gestions_des_notes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionsDesNotesApplicationTests {

	@Test
	void contextLoads() {
	}

}

