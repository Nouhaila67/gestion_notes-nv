package com.example.gestions_des_notes.controllers;
import com.example.gestions_des_notes.models.EducationalStructure;
import com.example.gestions_des_notes.service.EducationalStructureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/structures")
public class EducationalStructureControlle {
    @Autowired
    private EducationalStructureService educationalStructureService;

    // Créer une structure pédagogique
    @PostMapping("/add")
    public EducationalStructure createStructure(@RequestBody EducationalStructure structure) {
        return educationalStructureService.createStructure(structure);
    }

    // Modifier une structure pédagogique
    @PutMapping("/update/{id}")
    public EducationalStructure updateStructure(@PathVariable Long id, @RequestBody EducationalStructure structure) {
        return educationalStructureService.updateStructure(id, structure);
    }

    // Supprimer une structure pédagogique
    @DeleteMapping("/delete/{id}")
    public void deleteStructure(@PathVariable Long id) {
        educationalStructureService.deleteStructure(id);
    }

    // Lister toutes les structures pédagogiques
    @GetMapping("/all")
    public List<EducationalStructure> getAllStructures() {
        return educationalStructureService.getAllStructures();
    }
}
