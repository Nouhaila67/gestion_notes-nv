package com.example.gestions_des_notes.models;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Level {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String alias;

    @ManyToOne
    @JoinColumn(name = "next_level_id")
    private Level nextLevel;

    @OneToMany(mappedBy = "currentLevel", cascade = CascadeType.ALL)
    private List<Student> students;

    @OneToMany(mappedBy = "level", cascade = CascadeType.ALL) // Ensure mappedBy matches the property name in Module
    private List<Module> modules;

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public Level getNextLevel() {
        return nextLevel;
    }

    public void setNextLevel(Level nextLevel) {
        this.nextLevel = nextLevel;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

    public List<Module> getModules() {
        return modules;
    }

    public void setModules(List<Module> modules) {
        this.modules = modules;
    }
}