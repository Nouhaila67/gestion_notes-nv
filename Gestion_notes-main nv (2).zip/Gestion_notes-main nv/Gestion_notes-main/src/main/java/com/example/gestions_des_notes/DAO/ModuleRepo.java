package com.example.gestions_des_notes.DAO;

import com.example.gestions_des_notes.models.Module;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ModuleRepo extends JpaRepository<Module, Long> {
    // Vous pouvez ajouter des méthodes personnalisées ici si nécessaire
}