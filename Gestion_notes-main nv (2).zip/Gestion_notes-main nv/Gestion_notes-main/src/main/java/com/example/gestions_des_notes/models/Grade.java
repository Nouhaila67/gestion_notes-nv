package com.example.gestions_des_notes.models;

import jakarta.persistence.*;

@Entity
public class Grade {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    public void setModule(Module module) {
        this.module = module;
    }

    public void setValidationStatus(String validationStatus) {
        this.validationStatus = validationStatus;
    }

    public void setElement(Element element) {
        this.element = element;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    @ManyToOne
    @JoinColumn(name = "student_id")
    private Student student;

    public String getValidationStatus() {
        return validationStatus;
    }

    public Element getElement() {
        return element;
    }

    public Double getValue() {
        return value;
    }

    public Module getModule() {
        return module;
    }

    @ManyToOne
    @JoinColumn(name = "module_id")
    private Module module;

    public void setId(Long id) {
        this.id = id;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Grade(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    @ManyToOne
    @JoinColumn(name = "element_id")
    private Element element;

    private Double value;
    private String validationStatus; // V, R, NV

    // Getters and setters
}