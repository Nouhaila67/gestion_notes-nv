package com.example.gestions_des_notes.models;

import jakarta.persistence.*;
import java.time.LocalDateTime;
@Entity
public class AuditLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)  // Ensure proper mapping
    private User user;

    private String action;
    private LocalDateTime timestamp;

    // Getters and setters
}
