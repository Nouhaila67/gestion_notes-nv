package com.example.gestions_des_notes.controllers;

import com.example.gestions_des_notes.models.Grade;
import com.example.gestions_des_notes.service.GradeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/grades")
public class GradeController {

    @Autowired
    private GradeService gradeService;

    // Ajouter une note
    @PostMapping("/add")
    public Grade addGrade(@RequestBody Grade grade) {
        return gradeService.addGrade(grade);
    }

    // Calculer la moyenne d'un étudiant dans un module
    @GetMapping("/average/{studentId}/{moduleId}")
    public Double calculateModuleAverage(@PathVariable Long studentId, @PathVariable Long moduleId) {
        return gradeService.calculateModuleAverage(studentId, moduleId);
    }

    // Récupérer toutes les notes d'un étudiant
    @GetMapping("/student/{studentId}")
    public List<Grade> getGradesByStudent(@PathVariable Long studentId) {
        return gradeService.getGradesByStudent(studentId);
    }

    // Récupérer toutes les notes d'un module
    @GetMapping("/module/{moduleId}")
    public List<Grade> getGradesByModule(@PathVariable Long moduleId) {
        return gradeService.getGradesByModule(moduleId);
    }

    // Récupérer toutes les notes d'un élément
    @GetMapping("/element/{elementId}")
    public List<Grade> getGradesByElement(@PathVariable Long elementId) {
        return gradeService.getGradesByElement(elementId);
    }
}