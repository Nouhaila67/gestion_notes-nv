package com.example.gestions_des_notes.models;

import jakarta.persistence.*;

@Entity
public class Element {
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    public Element(Long id) {
        this.id = id;
    }

    @ManyToOne
    @JoinColumn(name = "module_id")
    private Module module;

    // Getters and setters
}