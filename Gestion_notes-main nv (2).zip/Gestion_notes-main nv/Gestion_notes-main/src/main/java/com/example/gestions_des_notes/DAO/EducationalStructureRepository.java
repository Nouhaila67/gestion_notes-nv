package com.example.gestions_des_notes.DAO;

import com.example.gestions_des_notes.models.EducationalStructure;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EducationalStructureRepository extends JpaRepository<EducationalStructure, Long> {
    // Custom query methods can be defined here if needed
}
