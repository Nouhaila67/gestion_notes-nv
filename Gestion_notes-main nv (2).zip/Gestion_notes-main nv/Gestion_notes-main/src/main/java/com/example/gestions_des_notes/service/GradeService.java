package com.example.gestions_des_notes.service;


import com.example.gestions_des_notes.DAO.ElementRepo;
import com.example.gestions_des_notes.DAO.GradeRepo;
import com.example.gestions_des_notes.DAO.ModuleRepo;
import com.example.gestions_des_notes.DAO.StudentRepo;
import com.example.gestions_des_notes.models.Grade;
import com.example.gestions_des_notes.models.Student;
import com.example.gestions_des_notes.models.Module;
import com.example.gestions_des_notes.models.Element;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GradeService {

    @Autowired
    private GradeRepo gradeRepo; // Repository pour les notes

    @Autowired
    private StudentRepo studentRepo; // Repository pour les étudiants

    @Autowired
    private ModuleRepo moduleRepo; // Repository pour les modules

    @Autowired
    private ElementRepo elementRepo; // Repository pour les éléments

    /**
     * Ajouter une note pour un étudiant dans un module et un élément.
     *
     * @param grade La note à ajouter.
     * @return La note sauvegardée.
     */
    public Grade addGrade(Grade grade) {
        // Vérifier si l'étudiant, le module et l'élément existent
        Student student = studentRepo.findById(grade.getStudent().getId())
                .orElseThrow(() -> new RuntimeException("Étudiant non trouvé"));
        Module module = moduleRepo.findById(grade.getModule().getId())
                .orElseThrow(() -> new RuntimeException("Module non trouvé"));
        Element element = elementRepo.findById(grade.getElement().getId())
                .orElseThrow(() -> new RuntimeException("Élément non trouvé"));

        // Associer l'étudiant, le module et l'élément à la note
        grade.setStudent(student);
        grade.setModule(module);
        grade.setElement(element);

        // Valider la note
        grade.setValidationStatus(validateGrade(grade.getValue(), module.getPassingScore(), module.getRetakeScore()));

        // Sauvegarder la note
        return gradeRepo.save(grade);
    }

    /**
     * Valider une note en fonction des seuils de validation.
     *
     * @param value        La valeur de la note.
     * @param passingScore Le seuil de validation (ex: 12).
     * @param retakeScore  Le seuil de rattrapage (ex: 8).
     * @return "V" si validé, "R" si rattrapage, "NV" si non validé.
     */
    public String validateGrade(Double value, Double passingScore, Double retakeScore) {
        if (value >= passingScore) {
            return "V"; // Validé
        } else if (value >= retakeScore) {
            return "R"; // Rattrapage
        } else {
            return "NV"; // Non Validé
        }
    }

    /**
     * Calculer la moyenne d'un étudiant dans un module.
     *
     * @param studentId L'ID de l'étudiant.
     * @param moduleId  L'ID du module.
     * @return La moyenne de l'étudiant dans le module.
     */
    public Double calculateModuleAverage(Long studentId, Long moduleId) {
        // Récupérer toutes les notes de l'étudiant dans ce module
        List<Grade> grades = gradeRepo.findByStudentIdAndModuleId(studentId, moduleId);
        if (grades.isEmpty()) {
            throw new RuntimeException("Aucune note trouvée pour cet étudiant dans ce module");
        }

        // Calculer la moyenne
        double sum = grades.stream().mapToDouble(Grade::getValue).sum();
        return sum / grades.size();
    }

    /**
     * Récupérer toutes les notes d'un étudiant.
     *
     * @param studentId L'ID de l'étudiant.
     * @return La liste des notes de l'étudiant.
     */
    public List<Grade> getGradesByStudent(Long studentId) {
        return gradeRepo.findByStudentId(studentId);
    }

    /**
     * Récupérer toutes les notes d'un module.
     *
     * @param moduleId L'ID du module.
     * @return La liste des notes du module.
     */
    public List<Grade> getGradesByModule(Long moduleId) {
        return gradeRepo.findByModuleId(moduleId);
    }

    /**
     * Récupérer toutes les notes d'un élément.
     *
     * @param elementId L'ID de l'élément.
     * @return La liste des notes de l'élément.
     */
    public List<Grade> getGradesByElement(Long elementId) {
        return gradeRepo.findByElementId(elementId);
    }
}




